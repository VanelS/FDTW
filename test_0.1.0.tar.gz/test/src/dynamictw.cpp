#include <Rcpp.h>
#include <stdio.h>
#include <stdlib.h>
using namespace Rcpp;



/*
* Calcul le minnimun entre deux valeurs
*  - x et y deux valeurs
*/
// [[Rcpp::export]]
double minn(double x, double y){
  return (x<y)?x:y;
}



/*
* Calcul la distance euclidienne entre deux vecteurs de reelles
* - x et y : des vecteurs de reelles
*/
double distance(double x, double y) {
  return pow((x - y), 2);
}

/*
* Calcul l'alignement ()Dynamic Time Warping) entre deux sÃ©ries temporelles
* - t1 et t2 : deux sÃ©ries temporelles
* - retourne la distance entre t1 et t2
*/
// [[Rcpp::export]]
double dynamictw(const std::vector<double>& t1, const std::vector<double>& t2) {
  int m = t1.size();
  int n = t2.size();

  //variable that content the distance
  double d;

  // Create the cost matrix
  double** cost = new double*[m];
  for(int i = 0; i < m; ++i)
    cost[i] = new double[n];

  cost[0][0] = distance(t1[0], t2[0]);

  // calculate first row
  for(int i = 1; i < m; i++){
    cost[i][0] = cost[i-1][0] + distance(t1[i], t2[0]);
  }

  // calculate first column
  for(int j = 1; j < n; j++)
    cost[0][j] = cost[0][j-1] + distance(t1[0], t2[j]);
  // fill matrix
  for(int i = 1; i < m; i++){
    for(int j = 1; j < n; j++){
      cost[i][j] = minn(cost[i-1][j], minn(cost[i][j-1], cost[i-1][j-1])) + distance(t1[i],t2[j]);
    }
  }

  d = cost[m-1][n-1];

  // Delate the cost matrix
  for(int i = 0; i < m; ++i)
    delete[] cost[i] ;
  delete[] cost;


  return sqrt(d);
}
