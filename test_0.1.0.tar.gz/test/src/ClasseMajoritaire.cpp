#include <Rcpp.h>
#include <stdio.h>
#include <stdlib.h>
using namespace Rcpp;



/*
 * DÃ©termine les classes distinctes contenues dans le tableau
 *  - classes_des instances : est un vecteur de classes pour les instances
 *  - Retourne les classes distinctes
 */
NumericVector tableau_classe_distincte(NumericVector classe_des_instances){

  int j = 0;
  int nb_instances = classe_des_instances.length();
  NumericVector tableau_classes_distinctes(nb_instances);
  NumericVector copie_classe_des_instances(nb_instances);

  for(int i = 0; i < nb_instances; i++){
    copie_classe_des_instances[i] = classe_des_instances[i];
  }


  for(int i = 0; i < (nb_instances - 1); i++){

    if(copie_classe_des_instances[i] != -1){// Chaque fois qu'on r?cup?re une classe, pour assurer l'unicit?, on replace tout ses doublons par -1

      tableau_classes_distinctes[j] = copie_classe_des_instances[i];

      for(int k = (i + 1); k < nb_instances; k++){ // Mettre tout les doublons ? -1
        if(copie_classe_des_instances[i] == copie_classe_des_instances[k]){
          copie_classe_des_instances[k] = -1;
        }else{}
      }

      j++;

    }else{}

  }
  if(copie_classe_des_instances[(nb_instances - 1)] != -1){
    tableau_classes_distinctes[j] = copie_classe_des_instances[(nb_instances - 1)];
    j++;
  }


  NumericVector out(j);
  int l;

  for(l = 0; l < j; l++){
    out[l] = tableau_classes_distinctes[l];
  }

  return out;
}



/*
* Calcul l'effectif de chaque classe
*  - classes : ensemble de classes distinctes
*  - classe de chaqu'une des instances
*  - retourne : l'effectif de chaque classes
*/
NumericVector effectif_chaque_classe(NumericVector classes, NumericVector classes_des_instances){

  int nb_classe = classes.length();
  int nb_instances = classes_des_instances.length();
  NumericVector effectif_par_classe(nb_classe);


  for(int i = 0; i < nb_instances; i++){
    for(int j = 0; j < nb_classe; j++){
      if(classes[j] == classes_des_instances[i]){
        effectif_par_classe[j] = effectif_par_classe[j] + 1;
      }else{}
    }
  }

  return effectif_par_classe;
}

/*
* Recherche l'indice du maximun
* - V : un vecteur de reelle
* - Retourne l'indice du maximun
*/
// [[Rcpp::export]]
int indice_maximun(NumericVector v){

  int n = v.length();
  int ind_max = 0;
  int max = v[0];

  for(int i = 1; i < n; i++){
    if(max < v[i]){
      max = v[i];
      ind_max = i;
    }else{}
  }

  return ind_max;
}


/*
 * Recherche la classe majoritaire
 * - classes_voisins : classes des k plus proches voisins
 * - classes_instances : classes des instances de la base de donnÃ©es
 */
// [[Rcpp::export]]
int ClasseMajoritaire(NumericVector classes_voisins, NumericVector classes_instances){
  NumericVector classes_distinctes = tableau_classe_distincte(classes_instances);
  NumericVector e = effectif_chaque_classe(classes_distinctes, classes_voisins);
  int ind_max = indice_maximun(e);

  return classes_distinctes[ind_max];

}
