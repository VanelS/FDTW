#include <Rcpp.h>
#include <stdio.h>
#include <stdlib.h>
using namespace Rcpp;

/*
* Normaliser les sÃ©riest temporelles
*   - prend en paramÃ¨tre une sÃ©rie temporelle
*   - retourne la sÃ©rie temporelle normalisÃ©e
*/
// [[Rcpp::export]]
NumericVector ZnormalisationDeTS(NumericVector t){
  return (t - mean(t)) / sd(t);
}
